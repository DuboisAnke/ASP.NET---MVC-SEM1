using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectCWeb_DuboisAnke_2ProA.Pages
{
    public class LogboekModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
